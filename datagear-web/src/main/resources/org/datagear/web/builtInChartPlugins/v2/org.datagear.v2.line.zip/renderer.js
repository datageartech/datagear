(function(plugin)
{
	return chartFactory.chartSupport.lineRenderer(plugin);
})
(plugin);