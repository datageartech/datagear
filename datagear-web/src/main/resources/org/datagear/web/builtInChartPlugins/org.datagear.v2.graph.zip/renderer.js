(function(plugin)
{
	return chartFactory.chartSupport.graphRenderer(plugin);
})
(plugin);