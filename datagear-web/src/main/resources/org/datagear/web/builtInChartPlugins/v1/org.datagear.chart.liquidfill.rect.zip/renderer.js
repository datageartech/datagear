(function(plugin)
{
	var r =
	{
		depend:
		{
			name: "echarts-liquidfill",
			version: "3.1.0",
			source: "lib/echarts-liquidfill-3.1.0/echarts-liquidfill.min.js"
		},
		render: function(chart)
		{
			var options = {dg: {shape: "rect"}};
			chartFactory.chartSupport.liquidfillRender(chart, options);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.liquidfillUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.liquidfillResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.liquidfillDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.liquidfillOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.liquidfillOff(chart, eventType, handler);
		},
		additions: { supportIgnoreFetch: true }
	};
	
	return r;
})
(plugin);