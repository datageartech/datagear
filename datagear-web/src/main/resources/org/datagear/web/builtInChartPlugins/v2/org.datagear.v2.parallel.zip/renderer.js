(function(plugin)
{
	return chartFactory.chartSupport.parallelRenderer(plugin);
})
(plugin);