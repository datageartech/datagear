(function(plugin)
{
	var config = { smooth: true };
	return chartFactory.chartSupport.lineRenderer(plugin, config);
})
(plugin);