(function(plugin)
{
	return chartFactory.chartSupport.boxplotRenderer(plugin);
})
(plugin);