(function(plugin)
{
	var config = { smooth: true, parallelLayout: "vertical" };
	return chartFactory.chartSupport.parallelRenderer(plugin, config);
})
(plugin);