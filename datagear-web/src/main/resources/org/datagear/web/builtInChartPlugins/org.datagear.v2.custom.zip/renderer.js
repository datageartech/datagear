(function(plugin)
{
	return chartFactory.chartSupport.customRenderer(plugin);
})
(plugin);