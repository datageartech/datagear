(function(plugin)
{
	var config =
	{
		interchangeAxis: true,
		series0: { symbol: "star", symbolSize: "50%", symbolRepeat: true, symbolMargin: "10%" },
		series1: { symbol: "star", symbolSize: "50%", symbolRepeat: "fixed", symbolMargin: "10%" }
	};
	
	return chartFactory.chartSupport.pictorialBarProgressRenderer(plugin, config);
})
(plugin);