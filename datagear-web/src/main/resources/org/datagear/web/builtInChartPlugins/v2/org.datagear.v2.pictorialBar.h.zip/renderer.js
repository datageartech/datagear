(function(plugin)
{
	var config = { interchangeAxis: true };
	return chartFactory.chartSupport.pictorialBarRenderer(plugin, config);
})
(plugin);