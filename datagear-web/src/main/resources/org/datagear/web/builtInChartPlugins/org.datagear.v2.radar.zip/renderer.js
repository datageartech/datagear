(function(plugin)
{
	return chartFactory.chartSupport.radarRenderer(plugin);
})
(plugin);