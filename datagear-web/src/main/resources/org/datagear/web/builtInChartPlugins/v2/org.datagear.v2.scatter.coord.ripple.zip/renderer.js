(function(plugin)
{
	return chartFactory.chartSupport.scatterCoordRippleRenderer(plugin);
})
(plugin);