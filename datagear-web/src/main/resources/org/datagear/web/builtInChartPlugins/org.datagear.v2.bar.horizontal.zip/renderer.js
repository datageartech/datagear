(function(plugin)
{
	var config = { horizontal: true };
	return chartFactory.chartSupport.barRenderer(plugin, config);
})
(plugin);