(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			var options = {dg: {horizontal: true}};
			chartFactory.chartSupport.pictorialBarProgressRender(chart, options);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.pictorialBarProgressUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.pictorialBarProgressResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.pictorialBarProgressDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.pictorialBarProgressOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.pictorialBarProgressOff(chart, eventType, handler);
		},
		additions: { supportIgnoreFetch: true }
	};
	
	return r;
})
(plugin);