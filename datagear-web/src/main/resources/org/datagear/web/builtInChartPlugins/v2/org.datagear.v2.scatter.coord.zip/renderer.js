(function(plugin)
{
	return chartFactory.chartSupport.scatterCoordRenderer(plugin);
})
(plugin);