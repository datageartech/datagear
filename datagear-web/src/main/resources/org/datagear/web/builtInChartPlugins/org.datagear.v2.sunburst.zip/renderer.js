(function(plugin)
{
	return chartFactory.chartSupport.sunburstRenderer(plugin);
})
(plugin);