(function(plugin)
{
	var r =
	{
		depend:
		{
			name: "jQuery",
			version: "3.7.1",
			source: "jquery-3.7.1/jquery-3.7.1.min.js"
		},
		render: function(){},
		update: function(){},
		destroy: function(){}
	};
	
	return r;
})
(plugin);