(function(plugin)
{
	return chartFactory.chartSupport.mapGraphRenderer(plugin);
})
(plugin);