(function(plugin)
{
	var config={ horizontal: true, stack: true };
	return chartFactory.chartSupport.barRenderer(plugin, config);
})
(plugin);