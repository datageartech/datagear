(function(plugin)
{
	return chartFactory.chartSupport.treemapRenderer(plugin);
})
(plugin);