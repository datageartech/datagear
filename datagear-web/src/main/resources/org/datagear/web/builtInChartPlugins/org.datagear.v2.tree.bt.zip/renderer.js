(function(plugin)
{
	var config = { orient: "BT" };
	return chartFactory.chartSupport.treeRenderer(plugin, config);
})
(plugin);