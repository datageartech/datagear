(function(plugin)
{
	var config = { hideName: true };
	return chartFactory.chartSupport.labelRenderer(plugin, config);
})
(plugin);