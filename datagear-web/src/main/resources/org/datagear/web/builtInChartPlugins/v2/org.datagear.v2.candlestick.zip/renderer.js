(function(plugin)
{
	return chartFactory.chartSupport.candlestickRenderer(plugin);
})
(plugin);