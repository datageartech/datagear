(function(plugin)
{
	var config={ radarShape: "circle" };
	return chartFactory.chartSupport.radarRenderer(plugin, config);
})
(plugin);