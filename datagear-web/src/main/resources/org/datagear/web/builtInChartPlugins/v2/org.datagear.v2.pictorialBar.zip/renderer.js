(function(plugin)
{
	return chartFactory.chartSupport.pictorialBarRenderer(plugin);
})
(plugin);