(function(plugin)
{
	var config = { orient: "RL" };
	return chartFactory.chartSupport.treeRenderer(plugin, config);
})
(plugin);