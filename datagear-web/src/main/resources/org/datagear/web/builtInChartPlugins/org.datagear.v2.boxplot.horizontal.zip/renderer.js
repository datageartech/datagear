(function(plugin)
{
	var config = { interchangeAxis: true };
	return chartFactory.chartSupport.boxplotRenderer(plugin, config);
})
(plugin);