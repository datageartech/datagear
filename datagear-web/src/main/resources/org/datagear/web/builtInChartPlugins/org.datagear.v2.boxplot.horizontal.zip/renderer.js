(function(plugin)
{
	var config = { horizontal:true };
	return chartFactory.chartSupport.boxplotRenderer(plugin, config);
})
(plugin);