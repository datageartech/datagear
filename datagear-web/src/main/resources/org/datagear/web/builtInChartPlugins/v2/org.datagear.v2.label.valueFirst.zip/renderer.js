(function(plugin)
{
	var config = { valueFirst: true };
	return chartFactory.chartSupport.labelRenderer(plugin, config);
})
(plugin);