(function(plugin)
{
	var config = { sort: "ascending" };
	return chartFactory.chartSupport.funnelRenderer(plugin, config);
})
(plugin);