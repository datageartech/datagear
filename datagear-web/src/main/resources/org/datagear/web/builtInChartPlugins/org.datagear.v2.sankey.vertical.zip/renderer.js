(function(plugin)
{
	var config = { orient: "vertical" };
	return chartFactory.chartSupport.sankeyRenderer(plugin, config);
})
(plugin);