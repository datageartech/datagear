(function(plugin)
{
	return chartFactory.chartSupport.wordcloudRenderer(plugin);
})
(plugin);