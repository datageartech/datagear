(function(plugin)
{
	return chartFactory.chartSupport.datetimeRenderer(plugin);
})
(plugin);