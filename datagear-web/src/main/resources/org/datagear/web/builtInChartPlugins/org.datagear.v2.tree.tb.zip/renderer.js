(function(plugin)
{
	var config = { orient: "TB" };
	return chartFactory.chartSupport.treeRenderer(plugin, config);
})
(plugin);