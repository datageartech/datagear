(function(plugin)
{
	var config = {multiple: true};
	return chartFactory.chartSupport.selectRenderer(plugin, config);
})
(plugin);