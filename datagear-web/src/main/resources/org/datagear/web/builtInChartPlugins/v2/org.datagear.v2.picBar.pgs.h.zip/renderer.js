(function(plugin)
{
	var config =
	{
		interchangeAxis: true,
		series0: { symbol: "rect", symbolSize: ["100%", "100%"], symbolRepeat: false, symbolMargin: 0 },
		series1: { symbol: "rect", symbolSize: ["100%", "100%"], symbolRepeat: false, symbolMargin: 0 }
	};
	
	return chartFactory.chartSupport.pictorialBarProgressRenderer(plugin, config);
})
(plugin);