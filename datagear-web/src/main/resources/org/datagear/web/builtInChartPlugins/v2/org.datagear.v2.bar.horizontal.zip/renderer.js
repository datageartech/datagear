(function(plugin)
{
	var config = { interchangeAxis: true };
	return chartFactory.chartSupport.barRenderer(plugin, config);
})
(plugin);