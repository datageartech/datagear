(function(plugin)
{
	var config = { gaugeType: "step" };
	return chartFactory.chartSupport.gaugeRenderer(plugin, config);
})
(plugin);