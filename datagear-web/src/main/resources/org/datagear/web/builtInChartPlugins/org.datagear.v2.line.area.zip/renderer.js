(function(plugin)
{
	var config = { area: true };
	return chartFactory.chartSupport.lineRenderer(plugin, config);
})
(plugin);