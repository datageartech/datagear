(function(plugin)
{
	return chartFactory.chartSupport.barRenderer(plugin);
})
(plugin);