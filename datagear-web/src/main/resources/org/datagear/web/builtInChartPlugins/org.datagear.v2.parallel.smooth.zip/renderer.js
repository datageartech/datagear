(function(plugin)
{
	var config = { smooth: true };
	return chartFactory.chartSupport.parallelRenderer(plugin, config);
})
(plugin);