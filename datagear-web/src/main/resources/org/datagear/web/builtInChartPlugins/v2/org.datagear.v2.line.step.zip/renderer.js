(function(plugin)
{
	var config = { step: true };
	return chartFactory.chartSupport.lineRenderer(plugin, config);
})
(plugin);