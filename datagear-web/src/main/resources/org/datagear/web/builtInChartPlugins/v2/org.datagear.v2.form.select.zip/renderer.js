(function(plugin)
{
	return chartFactory.chartSupport.selectRenderer(plugin);
})
(plugin);