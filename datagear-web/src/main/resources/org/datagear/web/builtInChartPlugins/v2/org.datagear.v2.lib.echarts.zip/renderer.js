(function(plugin)
{
	var r =
	{
		depend:
		{
			name: "echarts",
			version: "6.0.0",
			source: "echarts-6.0.0/echarts.min.js"
		},
		render: function(){},
		update: function(){},
		destroy: function(){}
	};
	
	return r;
})
(plugin);