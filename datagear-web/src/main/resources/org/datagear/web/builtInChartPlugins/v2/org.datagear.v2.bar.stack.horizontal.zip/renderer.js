(function(plugin)
{
	var config={ interchangeAxis: true, stack: true };
	return chartFactory.chartSupport.barRenderer(plugin, config);
})
(plugin);