{
	id : 'org.datagear.chart.bar',
	nameLabel : '柱状图',
	descLabel : '柱状图',
	dataSigns :
	[
		{ name : "xvalue", nameLabel : "横坐标", required: true, multiple: false },
		{ name : "yvalue", nameLabel : "纵坐标", required: true, multiple: true }
	],
	version: "0.1.0",
	order : 101,
	chartRender:
	{
	/**
	 * 依赖：
	 * chartUtil
	 * echarts
	 */
		render: function(chart)
		{
			chart.echarts = {};
			
			var options =
			{
				title: {
			        text: chartUtil.propertyValueName(chart),
			        left: "center"
			    },
				tooltip:
				{
					trigger: "item"
				},
				legend:
				{
					orient: "horizontal",
					top: 25,
					data: []
				},
				grid:
				{
					top: 80
				},
				xAxis: {
					type: 'category',
					boundaryGap: true,
					data: []
				},
				yAxis: {
					type: 'value'
				},
				series: [{
					name: "",
					type: 'bar',
					data: []
				}]
			};
			
			chart.echarts.chart = chartUtil.echarts.init(chart, options);
		},
		update: function(chart, results)
		{
			var chartDataSets = chartUtil.chartDataSets(chart);
			
			var legendData = [];
			var xAxisData = [];
			var series = [];
			
			for(var i=0; i<chartDataSets.length; i++)
			{
				var chartDataSet = chartDataSets[i];
				var dataSetName = chartUtil.dataSetName(chartDataSet);
				var result = chartUtil.resultIndex(results, i);
				
				if(i == 0)
				{
					var xp = chartUtil.dataSetPropertyOfSign(chartDataSet, "xvalue");
					xAxisData = chartUtil.resultColumnArrays(result, xp);
				}
				
				var yp = chartUtil.dataSetPropertyOfSign(chartDataSet, "yvalue");
				var data = chartUtil.resultColumnArrays(result, yp);
				
				legendData[i] = dataSetName;
				series[i] = {name: dataSetName, type: "bar", data: data};
			}
			
			var options = { legend: {data: legendData}, xAxis : { data : xAxisData }, series: series };
			chart.echarts.chart.setOption(options);
		}
	}
}