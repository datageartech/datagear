{
	id: "org.datagear.chart.funnel",
	nameLabel: "漏斗图",
	descLabel: "漏斗图",
	dataSigns:
	[
		{ name: "name", nameLabel: "名称", required: true, multiple: false },
		{ name: "value", nameLabel: "数值", required: true, multiple: true }
	],
	version: "0.1.0",
	order: 118,
	chartRender:
	{
	/**
	 * 依赖：
	 * chartUtil
	 * echarts
	 */
		render: function(chart)
		{
			chart.echarts = {};
			
			var options =
			{
				title: {
			        text: chartUtil.propertyValueName(chart)
			    },
			    tooltip:
			    {
			        trigger: "item",
			        formatter: "{a} <br/>{b} : {c}"
			    },
				legend:
				{
					data: []
				},
				series:
				[
					{
			            name: chartUtil.propertyValueName(chart),
			            type: "funnel",
			            left: "10%",
			            top: 80,
			            bottom: 60,
			            width: "80%",
			            min: 0,
			            max: 100,
			            minSize: "0%",
			            maxSize: "100%",
			            sort: "descending",
			            gap: 2,
			            label:
			            {
			                show: true,
			                position: "inside"
			            },
			            emphasis:
			            {
			                label:
			                {
			                    fontSize: 20
			                }
			            },
			            data: []
			        }
				]
			};
			
			chart.echarts.chart = chartUtil.echarts.init(chart, options);
		},
		update: function(chart, results)
		{
			var chartDataSets = chartUtil.chartDataSets(chart);

			var legendData = [];
			var seriesData = [];
			var min = 0;
			var max = 100;

			for(var i=0; i<chartDataSets.length; i++)
			{
				var chartDataSet = chartDataSets[i];
				var dataSetName = chartUtil.dataSetName(chartDataSet);
				var result = chartUtil.resultIndex(results, i);

				var np = chartUtil.dataSetPropertyOfSign(chartDataSet, "name");
				var npv = chartUtil.resultColumnArrays(result, np);
				var vp = chartUtil.dataSetPropertyOfSign(chartDataSet, "value");
				var nvv = chartUtil.resultNameValueObjects(result, np, vp);
				
				legendData = legendData.concat(npv);
				seriesData = seriesData.concat(nvv);
			}
			
			for(var i=0; i<seriesData.length; i++)
			{
				var nvv = seriesData[i];
				var v = (nvv ? (nvv.value || 0) : 0);
				
				if(v < min)
					min = v;
				else if(v > max)
					max = v;
			}
			
			var options = { legend: { data: legendData }, series: [ {min: min, max: max, data: seriesData } ] };
			chart.echarts.chart.setOption(options);
		}
	}
}