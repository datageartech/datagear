(function(plugin)
{
	var r =
	{
		render : function(chart)
		{
			var options = {dg: {gaugeType: "step"}};
			chartFactory.chartSupport.gaugeRender(chart, options);
		},
		update : function(chart, results)
		{
			chartFactory.chartSupport.gaugeUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.gaugeResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.gaugeDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.gaugeOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.gaugeOff(chart, eventType, handler);
		}
	};
	
	return r;
})
(plugin);