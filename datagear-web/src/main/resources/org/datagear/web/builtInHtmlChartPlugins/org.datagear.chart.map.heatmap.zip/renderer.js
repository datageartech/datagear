(function(plugin)
{
	return chartFactory.chartSupport.mapHeatmapRenderer(plugin);
})
(plugin);