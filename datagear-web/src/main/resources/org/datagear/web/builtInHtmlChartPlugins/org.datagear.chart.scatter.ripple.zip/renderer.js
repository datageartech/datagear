(function(plugin)
{
	return chartFactory.chartSupport.scatterRippleRenderer(plugin);
})
(plugin);