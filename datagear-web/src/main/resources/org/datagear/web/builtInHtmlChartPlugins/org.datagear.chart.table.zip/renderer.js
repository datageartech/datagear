(function(plugin)
{
	return chartFactory.chartSupport.tableRenderer(plugin);
})
(plugin);