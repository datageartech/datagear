(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			var options = {dg: {rose: true}};
			chartFactory.chartSupport.pieRender(chart, options);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.pieUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.pieResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.pieDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.pieOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.pieOff(chart, eventType, handler);
		},
		additions: { supportIgnoreFetch: true }
	};
	
	return r;
})
(plugin);