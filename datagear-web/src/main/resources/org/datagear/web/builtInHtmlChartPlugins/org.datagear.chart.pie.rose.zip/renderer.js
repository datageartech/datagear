(function(plugin)
{
	var config = { rose: true };
	return chartFactory.chartSupport.pieRenderer(plugin, config);
})
(plugin);