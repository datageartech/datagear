{
	id : 'org.datagear.chart.label',
	nameLabel : '标签卡',
	descLabel : '标签卡',
	dataSigns :
	[
		{ name : "value", nameLabel : "标签值", required: true, multiple: true }
	],
	version: "0.1.0",
	order : 111,
	chartRender:
	{
	/**
	 * 依赖：
	 * chartUtil
	 */
		render: function(chart)
		{
			
		},
		update: function(chart, results)
		{
			var chartDataSets = chartUtil.chartDataSets(chart);
			
			var $parent = $("#" + chart.elementId);
			$(".dg-chart-label", $parent).addClass("dg-chart-label-pending");
			
			for(var i=0; i<chartDataSets.length; i++)
			{
				var chartDataSet = chartDataSets[i];
				var dataSetName = chartUtil.dataSetName(chartDataSet);
				var result = chartUtil.resultIndex(results, i);
				
				var vp = chartUtil.dataSetPropertiesOfSign(chartDataSet, "value");
				var vv = chartUtil.resultRowArrays(result, vp);
				
				for(var j=0; j<vv.length; j++)
				{
					var vvj = vv[j];
					
					for(var k=0; k<vvj.length; k++)
					{
						var cssName = "dg-chart-label-"+i+"-"+j+"-"+k;
						var value = vv[j][k];
						
						var $label = $("."+ cssName, $parent);
						if($label.length == 0)
							$label = $("<span class='dg-chart-label dg-chart-label-"+i+" dg-chart-label-"+i+"-"+j+" "+cssName+"'></span>").appendTo($parent);
						else
							$label.removeClass("dg-chart-label-pending");
						
						$label.html(value);
					}
				}
			}
			
			$(".dg-chart-label-pending", $parent).remove();
		}
	}
}