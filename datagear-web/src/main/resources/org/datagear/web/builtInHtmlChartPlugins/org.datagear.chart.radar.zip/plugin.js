{
	id: "org.datagear.chart.radar",
	nameLabel: "雷达图",
	descLabel: "雷达图",
	dataSigns:
	[
		{ name: "name", nameLabel: "名称", required: true, multiple: false },
		{ name: "dataName", nameLabel: "指标名称", required: true, multiple: true },
		{ name: "dataValue", nameLabel: "指标数值", required: true, multiple: true },
		{ name: "dataMax", nameLabel: "指标上限", required: true, multiple: true }
	],
	version: "0.1.0",
	order: 117,
	chartRender:
	{
	/**
	 * 依赖：
	 * chartUtil
	 * echarts
	 */
		render: function(chart)
		{
			chart.echarts = {};
			
			var options =
			{
				title: {
			        text: chartUtil.propertyValueName(chart)
			    },
				tooltip:
				{
					trigger: "item"
				},
				legend:
				{
					data: []
				},
				radar:
				{
					center: ["50%", "60%"],
					radius: "70%",
					nameGap: 6,
					indicator: []
				},
				series: [{
					type: "radar",
					data: []
				}]
			};
			
			$.extend(options, chartUtil.chartElementOptions(chart));
			
			chart.echarts.chart = chartUtil.echarts.init(chart, options);
		},
		update: function(chart, results)
		{
			var chartDataSets = chartUtil.chartDataSets(chart);
			
			var legendData = [];
			var indicatorData = [];
			var series = [];
			
			for(var i=0; i<chartDataSets.length; i++)
			{
				var chartDataSet = chartDataSets[i];
				var dataSetName = chartUtil.dataSetName(chartDataSet);
				var result = chartUtil.resultIndex(results, i);
				
				var np = chartUtil.dataSetPropertyOfSign(chartDataSet, "name");
				var nv = chartUtil.resultColumnArrays(result, np);
				legendData = legendData.concat(nv);
				
				if(i == 0)
				{
					var dnp = chartUtil.dataSetPropertiesOfSign(chartDataSet, "dataName");
					var dnpv = chartUtil.resultRowArrays(result, dnp, 1);
					dnpv = (dnpv.length > 0 ? dnpv[0] : []);
					var dmp = chartUtil.dataSetPropertiesOfSign(chartDataSet, "dataMax");
					var dmpv = chartUtil.resultRowArrays(result, dmp, 1);
					dmpv = (dmpv.length > 0 ? dmpv[0] : []);
					
					var indicatorLen = Math.min(dnp.length, dmp.length);
					
					for(var j=0; j<indicatorLen; j++)
					{
						var indicator = {name: dnpv[j], max: dmpv[j]};
						indicatorData[j] = indicator;
					}
				}
				
				var dvp = chartUtil.dataSetPropertiesOfSign(chartDataSet, "dataValue");
				var dvpv = chartUtil.resultRowArrays(result, dvp);
				
				for(var j=0; j<nv.length; j++)
				{
					series.push({type: "radar", data: [{name: nv[j], value: dvpv[j]}]});
				}
			}
			
			var options = { legend: {data: legendData}, radar: {indicator: indicatorData}, series: series };
			chart.echarts.chart.setOption(options);
		}
	}
}