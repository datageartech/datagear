(function(plugin)
{
	return chartFactory.chartSupport.mapFlylineRenderer(plugin);
})
(plugin);