(function(plugin)
{
	var config = { splitDataSet: true, seriesLayout: "nest" };
	return chartFactory.chartSupport.pieRenderer(plugin, config);
})
(plugin);