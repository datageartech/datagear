(function(plugin)
{
	return chartFactory.chartSupport.pictorialBarProgressRenderer(plugin);
})
(plugin);