(function(plugin)
{
	return chartFactory.chartSupport.gaugeRenderer(plugin);
})
(plugin);