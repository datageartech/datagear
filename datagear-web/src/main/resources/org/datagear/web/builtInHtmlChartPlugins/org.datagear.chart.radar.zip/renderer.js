(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			chartFactory.chartSupport.radarRender(chart);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.radarUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.radarResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.radarDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.radarOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.radarOff(chart, eventType, handler);
		},
		additions: { supportIgnoreFetch: true }
	};
	
	return r;
})
(plugin);