(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			chartFactory.chartSupport.candlestickRender(chart);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.candlestickUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.candlestickResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.candlestickDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.candlestickOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.candlestickOff(chart, eventType, handler);
		}
	};
	
	return r;
})
(plugin);