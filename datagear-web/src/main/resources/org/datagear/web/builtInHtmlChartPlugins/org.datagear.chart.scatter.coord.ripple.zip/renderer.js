(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			chartFactory.chartSupport.scatterCoordRippleRender(chart);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.scatterCoordRippleUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.scatterCoordRippleResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.scatterCoordRippleDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.scatterCoordRippleOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.scatterCoordRippleOff(chart, eventType, handler);
		}
	};
	
	return r;
})
(plugin);