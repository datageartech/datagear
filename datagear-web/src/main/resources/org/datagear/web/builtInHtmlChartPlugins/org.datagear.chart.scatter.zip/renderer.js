(function(plugin)
{
	return chartFactory.chartSupport.scatterRenderer(plugin);
})
(plugin);