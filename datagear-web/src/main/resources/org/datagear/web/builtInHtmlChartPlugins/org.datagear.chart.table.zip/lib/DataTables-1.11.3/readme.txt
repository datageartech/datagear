https://datatables.net/download/

Choose a styling framework
	jQuery UI
	
Select packages
	DataTables
	
Extensions
	AutoFill
	ColReorder
	FixedColumns
	FixedHeader
	KeyTable
	Responsive
	RowGroup
	RowReorder
	Scroller
	Select
