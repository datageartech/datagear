{
	id: "org.datagear.chart.scatter",
	nameLabel: "散点图",
	descLabel: "散点图",
	dataSigns:
	[
		{ name: "xvalue", nameLabel: "横坐标", required: true, multiple: false },
		{ name: "yvalue", nameLabel: "纵坐标", required: true, multiple: true }
	],
	version: "0.1.0",
	order: 104,
	chartRender:
	{
	/**
	 * 依赖：
	 * chartUtil
	 * echarts
	 */
		render: function(chart)
		{
			chart.echarts = {};
			
			var options =
			{
				title: {
			        text: chartUtil.propertyValueName(chart),
			        left: "center"
			    },
				tooltip:
				{
					trigger: "item"
				},
				legend:
				{
					orient: "horizontal",
					top: 25,
					data: []
				},
				grid:
				{
					top: 80
				},
				xAxis: {
				},
				yAxis: {
				},
				series: [{
					name: "",
					type: "scatter",
					data: []
				}]
			};
			
			chart.echarts.chart = chartUtil.echarts.init(chart, options);
		},
		update: function(chart, results)
		{
			var chartDataSets = chartUtil.chartDataSets(chart);
			
			var legendData = [];
			var series = [];
			
			for(var i=0; i<chartDataSets.length; i++)
			{
				var chartDataSet = chartDataSets[i];
				var dataSetName = chartUtil.dataSetName(chartDataSet);
				var properties = [chartUtil.dataSetPropertyOfSign(chartDataSet, "xvalue"), chartUtil.dataSetPropertyOfSign(chartDataSet, "yvalue")];
				var result = chartUtil.resultIndex(results, i);
				var data = chartUtil.resultRowArrays(result, properties);
				
				legendData[i] = dataSetName;
				series[i] = {name: dataSetName, type: "scatter", symbolSize: 10, data: data};
			}
			
			var options = { legend: {data: legendData}, series: series };
			chart.echarts.chart.setOption(options);
		}
	}
}