(function(plugin)
{
	return chartFactory.chartSupport.barPolarRenderer(plugin);
})
(plugin);