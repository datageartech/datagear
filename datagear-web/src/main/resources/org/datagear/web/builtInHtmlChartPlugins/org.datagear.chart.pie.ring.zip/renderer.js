(function(plugin)
{
	var config = { ring: true };
	return chartFactory.chartSupport.pieRenderer(plugin, config);
})
(plugin);