(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			var options = {dg: {orient: "vertical"}};
			chartFactory.chartSupport.sankeyRender(chart, options);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.sankeyUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.sankeyResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.sankeyDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.sankeyOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.sankeyOff(chart, eventType, handler);
		}
	};
	
	return r;
})
(plugin);