(function(plugin)
{
	var config = {multiple: false};
	return chartFactory.chartSupport.selectRenderer(plugin, config);
})
(plugin);