(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			var options = {multiple: false};
			chartFactory.chartSupport.selectRender(chart, options);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.selectUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.selectResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.selectDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.selectOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.selectOff(chart, eventType, handler);
		}
	};
	
	return r;
})
(plugin);