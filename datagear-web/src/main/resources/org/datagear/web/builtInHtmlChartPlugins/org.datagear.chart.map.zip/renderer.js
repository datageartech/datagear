(function(plugin)
{
	return chartFactory.chartSupport.mapRenderer(plugin);
})
(plugin);