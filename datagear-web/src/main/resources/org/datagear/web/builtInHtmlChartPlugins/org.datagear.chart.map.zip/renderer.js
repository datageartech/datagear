(function(plugin)
{
	var r =
	{
		asyncRender: true,
		render: function(chart)
		{
			chartFactory.chartSupport.mapRender(chart);
		},
		asyncUpdate: true,
		update: function(chart, results)
		{
			chartFactory.chartSupport.mapUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.mapResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.mapDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.mapOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.mapOff(chart, eventType, handler);
		}
	};
	
	return r;
})
(plugin);