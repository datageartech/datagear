(function(plugin)
{
	var config = { shape: "rect" };
	return chartFactory.chartSupport.liquidfillRenderer(plugin, config);
})
(plugin);