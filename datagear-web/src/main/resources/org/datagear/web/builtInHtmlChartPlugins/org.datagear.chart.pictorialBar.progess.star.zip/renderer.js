(function(plugin)
{
	var config =
	{
		symbol: "star", symbolSize: "50%",
		symbolMargin: "10%", symbolRepeat: true, symbolRepeatForBg: "fixed"
	};
	
	return chartFactory.chartSupport.pictorialBarProgressRenderer(plugin, config);
})
(plugin);