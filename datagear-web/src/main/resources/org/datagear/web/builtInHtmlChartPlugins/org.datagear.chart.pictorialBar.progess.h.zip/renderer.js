(function(plugin)
{
	var config = { horizontal: true };
	return chartFactory.chartSupport.pictorialBarProgressRenderer(plugin, config);
})
(plugin);