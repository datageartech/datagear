(function(plugin)
{
	return chartFactory.chartSupport.heatmapRenderer(plugin);
})
(plugin);