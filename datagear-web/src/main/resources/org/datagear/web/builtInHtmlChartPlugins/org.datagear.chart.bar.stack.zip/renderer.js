(function(plugin)
{
	var config={ stack: true };
	return chartFactory.chartSupport.barRenderer(plugin, config);
})
(plugin);