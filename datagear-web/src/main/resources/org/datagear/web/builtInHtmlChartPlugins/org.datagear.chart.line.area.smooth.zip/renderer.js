(function(plugin)
{
	var config = { smooth: true, area: true };
	return chartFactory.chartSupport.lineRenderer(plugin, config);
})
(plugin);