(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			var options={ dg: { stack: true } };
			chartFactory.chartSupport.barPolarRender(chart, options);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.barPolarUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.barPolarResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.barPolarDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.barPolarOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.barPolarOff(chart, eventType, handler);
		}
	};
	
	return r;
})
(plugin);