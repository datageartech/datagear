(function(plugin)
{
	var config={ stack: true };
	return chartFactory.chartSupport.barPolarRenderer(plugin, config);
})
(plugin);