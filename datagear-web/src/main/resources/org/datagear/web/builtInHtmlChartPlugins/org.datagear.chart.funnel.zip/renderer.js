(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			chartFactory.chartSupport.funnelRender(chart);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.funnelUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.funnelResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.funnelDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.funnelOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.funnelOff(chart, eventType, handler);
		}
	};
	
	return r;
})
(plugin);