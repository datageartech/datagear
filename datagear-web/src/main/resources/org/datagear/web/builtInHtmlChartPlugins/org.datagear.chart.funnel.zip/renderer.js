(function(plugin)
{
	return chartFactory.chartSupport.funnelRenderer(plugin);
})
(plugin);