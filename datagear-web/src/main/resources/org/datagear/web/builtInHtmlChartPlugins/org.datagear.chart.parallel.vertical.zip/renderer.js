(function(plugin)
{
	var config = { parallelLayout: "vertical" };
	return chartFactory.chartSupport.parallelRenderer(plugin, config);
})
(plugin);