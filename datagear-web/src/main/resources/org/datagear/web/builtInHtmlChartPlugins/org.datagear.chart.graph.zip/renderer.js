(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			chartFactory.chartSupport.graphRender(chart);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.graphUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.graphResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.graphDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.graphOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.graphOff(chart, eventType, handler);
		}
	};
	
	return r;
})
(plugin);