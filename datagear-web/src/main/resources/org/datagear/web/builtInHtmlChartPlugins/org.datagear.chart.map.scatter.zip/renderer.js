(function(plugin)
{
	return chartFactory.chartSupport.mapScatterRenderer(plugin);
})
(plugin);