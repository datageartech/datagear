(function(plugin)
{
	var r =
	{
		asyncRender: true,
		render: function(chart)
		{
			chartFactory.chartSupport.mapScatterRender(chart);
		},
		asyncUpdate: true,
		update: function(chart, results)
		{
			chartFactory.chartSupport.mapScatterUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.mapScatterResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.mapScatterDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.mapScatterOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.mapScatterOff(chart, eventType, handler);
		}
	};
	
	return r;
})
(plugin);