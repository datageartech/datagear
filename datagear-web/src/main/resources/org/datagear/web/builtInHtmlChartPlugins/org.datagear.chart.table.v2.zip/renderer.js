(function(plugin)
{
	var r =
	{
		depend:
		{
			name: "DataTable",
			version: "2.3.1",
			source:
			[
				"lib/DataTables-2.3.1/datatables.min.css",
				"lib/DataTables-2.3.1/datatables.min.js"
			]
		},
		render: function(chart)
		{
			chartFactory.chartSupport.tableRender(chart);
		},
		update: function(chart, chartResult)
		{
			chartFactory.chartSupport.tableUpdate(chart, chartResult);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.tableResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.tableDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.tableOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.tableOff(chart, eventType, handler);
		}
	};
	
	return r;
})
(plugin);