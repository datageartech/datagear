(function(plugin)
{
	return chartFactory.chartSupport.liquidfillRenderer(plugin);
})
(plugin);