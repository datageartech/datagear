(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			chartFactory.chartSupport.sunburstRender(chart);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.sunburstUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.sunburstResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.sunburstDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.sunburstOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.sunburstOff(chart, eventType, handler);
		}
	};
	
	return r;
})
(plugin);