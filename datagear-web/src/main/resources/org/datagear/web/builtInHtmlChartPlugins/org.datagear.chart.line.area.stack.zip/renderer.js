(function(plugin)
{
	var config = { stack: true, area: true };
	return chartFactory.chartSupport.lineRenderer(plugin, config);
})
(plugin);