(function(plugin)
{
	var r =
	{
		asyncRender: function(chart)
		{
			return chartFactory.chartSupport.customAsyncRender(chart);
		},
		render: function(chart)
		{
			chartFactory.chartSupport.customRender(chart);
		},
		asyncUpdate: function(chart, results)
		{
			return chartFactory.chartSupport.customAsyncUpdate(chart, results);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.customUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.customResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.customDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.customOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.customOff(chart, eventType, handler);
		}
	};
	
	return r;
})
(plugin);