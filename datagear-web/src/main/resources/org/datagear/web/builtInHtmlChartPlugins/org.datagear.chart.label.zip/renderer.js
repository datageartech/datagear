(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			chartFactory.chartSupport.labelRender(chart);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.labelUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.labelResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.labelDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.labelOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.labelOff(chart, eventType, handler);
		}
	};
	
	return r;
})
(plugin);