(function(plugin)
{
	return chartFactory.chartSupport.labelRenderer(plugin);
})
(plugin);