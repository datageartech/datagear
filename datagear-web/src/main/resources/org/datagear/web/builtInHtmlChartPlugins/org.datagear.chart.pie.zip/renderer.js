(function(plugin)
{
	return chartFactory.chartSupport.pieRenderer(plugin);
})
(plugin);