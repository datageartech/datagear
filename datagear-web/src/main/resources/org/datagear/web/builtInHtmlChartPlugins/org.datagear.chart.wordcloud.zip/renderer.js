(function(plugin)
{
	var r =
	{
		depend:
		{
			name: "echarts-wordcloud",
			version: "2.0.0",
			source: "lib/echarts-wordcloud-2.0.0/echarts-wordcloud.min.js"
		},
		render: function(chart)
		{
			chartFactory.chartSupport.wordcloudRender(chart);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.wordcloudUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.wordcloudResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.wordcloudDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.wordcloudOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.wordcloudOff(chart, eventType, handler);
		}
	};
	
	return r;
})
(plugin);