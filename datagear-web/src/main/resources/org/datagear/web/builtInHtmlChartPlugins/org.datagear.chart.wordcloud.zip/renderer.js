(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			chartFactory.chartSupport.wordcloudRender(chart);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.wordcloudUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.wordcloudResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.wordcloudDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.wordcloudOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.wordcloudOff(chart, eventType, handler);
		}
	};
	
	return r;
})
(plugin);