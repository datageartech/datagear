(function(plugin)
{
	var config={ axisType: "angle", stack: true };
	return chartFactory.chartSupport.barPolarRenderer(plugin, config);
})
(plugin);