(function(plugin)
{
	var config = { shape: "diamond" };
	return chartFactory.chartSupport.liquidfillRenderer(plugin, config);
})
(plugin);