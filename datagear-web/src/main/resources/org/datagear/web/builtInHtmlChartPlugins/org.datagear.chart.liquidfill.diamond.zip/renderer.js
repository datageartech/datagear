(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			var options = {dg: {shape: "diamond"}};
			chartFactory.chartSupport.liquidfillRender(chart, options);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.liquidfillUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.liquidfillResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.liquidfillDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.liquidfillOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.liquidfillOff(chart, eventType, handler);
		}
	};
	
	return r;
})
(plugin);