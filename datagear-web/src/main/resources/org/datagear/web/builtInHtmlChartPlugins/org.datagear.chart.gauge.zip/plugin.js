{
	id : "org.datagear.chart.gauge",
	nameLabel : "仪表盘",
	descLabel : "仪表盘",
	dataSigns :
	[
		{ name : "value", nameLabel : "数值", required: true, multiple: false },
		{ name : "min", nameLabel : "最小值", required: false, multiple: false },
		{ name : "max", nameLabel : "最大值", required: false, multiple: false }
	],
	version: "0.1.0",
	order : 115,
	chartRender :
	{
		render : function(chart)
		{
			chart.echarts = {};
			
			var options =
			{
				title: {
			        text: chartUtil.propertyValueName(chart)
			    },
				tooltip:
				{
					formatter: "{a} <br/>{b} : {c}"
				},
				series:
				[
					{
						name: chartUtil.propertyValueName(chart),
						type: "gauge",
						detail: {formatter: "{value}"},
						data: [{value: 0, name: ''}]
					}
				]
			};
			
			chart.echarts.chart = chartUtil.echarts.init(chart, options);
		},
		update : function(chart, results)
		{
			var chartDataSet = chartUtil.firstChartDataSet(chart);
			var result = chartUtil.resultFirst(results);
			
			var minp = chartUtil.dataSetPropertyOfSign(chartDataSet, "min");
			var maxp = chartUtil.dataSetPropertyOfSign(chartDataSet, "max");
			var vp = chartUtil.dataSetPropertyOfSign(chartDataSet, "value");
			
			var min = (chartUtil.resultCell(result, minp) || 0);
			var max = (chartUtil.resultCell(result, maxp) || 100);
			var value = (chartUtil.resultCell(result, vp) || 0);
			
			var options = { series : 
				[
					{
						min: min, max: max,
						data: [{ value: value, name: chartUtil.dataSetPropertyLabel(vp) }]
					}
				]};
			
			chart.echarts.chart.setOption(options);
		}
	}
}