(function(plugin)
{
	var config = { horizontal: true };
	return chartFactory.chartSupport.pictorialBarRenderer(plugin, config);
})
(plugin);