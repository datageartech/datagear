(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			chartFactory.chartSupport.treeRender(chart);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.treeUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.treeResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.treeDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.treeOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.treeOff(chart, eventType, handler);
		},
		additions: { supportIgnoreFetch: true }
	};
	
	return r;
})
(plugin);