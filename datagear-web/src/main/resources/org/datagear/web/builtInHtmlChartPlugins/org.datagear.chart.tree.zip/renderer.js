(function(plugin)
{
	return chartFactory.chartSupport.treeRenderer(plugin);
})
(plugin);