(function(plugin)
{
	var config={ axisType: "angle" };
	return chartFactory.chartSupport.barPolarRenderer(plugin, config);
})
(plugin);