(function(plugin)
{
	return chartFactory.chartSupport.themeRiverRenderer(plugin);
})
(plugin);