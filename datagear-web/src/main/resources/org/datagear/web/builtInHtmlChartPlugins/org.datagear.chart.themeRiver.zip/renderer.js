(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			chartFactory.chartSupport.themeRiverRender(chart);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.themeRiverUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.themeRiverResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.themeRiverDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.themeRiverOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.themeRiverOff(chart, eventType, handler);
		}
	};
	
	return r;
})
(plugin);