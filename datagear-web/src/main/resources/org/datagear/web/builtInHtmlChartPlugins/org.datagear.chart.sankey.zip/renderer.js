(function(plugin)
{
	return chartFactory.chartSupport.sankeyRenderer(plugin);
})
(plugin);