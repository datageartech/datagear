(function(plugin)
{
	var config = { gaugeType: "ring"};
	return chartFactory.chartSupport.gaugeRenderer(plugin, config);
})
(plugin);