(function(plugin)
{
	var config = { layout: "circular" };
	return chartFactory.chartSupport.graphRenderer(plugin, config);
})
(plugin);