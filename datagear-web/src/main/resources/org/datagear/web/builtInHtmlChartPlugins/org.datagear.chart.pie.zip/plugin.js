{
	id: "org.datagear.chart.pie",
	nameLabel: "饼图",
	descLabel: "饼图",
	dataSigns:
	[
		{ name: "name", nameLabel: "名称", required: true, multiple: false },
		{ name: "value", nameLabel: "数值", required: true, multiple: true }
	],
	version: "0.1.0",
	order: 102,
	chartRender:
	{
	/**
	 * 依赖：
	 * chartUtil
	 * echarts
	 */
		render: function(chart)
		{
			chart.echarts = {};
			
			var options =
			{
				title: {
			        text: chartUtil.propertyValueName(chart),
			        left: "center"
			    },
				tooltip:
				{
					trigger: "item",
					formatter: "{a} <br/>{b}: {c} ({d}%)"
				},
				legend:
				{
					orient: "horizontal",
					top: 25,
					data: []
				},
				grid:
				{
					top: 80
				},
				series:
				[
					{
						name: chartUtil.propertyValueName(chart),
						type: "pie",
						radius: "55%",
						center: ["50%", "60%"],
						data: [],
						emphasis:
						{
							itemStyle:
							{
								shadowBlur: 10,
								shadowOffsetX: 0,
								shadowColor: chartUtil.chartTheme(chart).envLeastColor
							}
						}
					}
				]
			};
			
			chart.echarts.chart = chartUtil.echarts.init(chart, options);
		},
		update: function(chart, results)
		{
			var chartDataSets = chartUtil.chartDataSets(chart);

			var legendData = [];
			var seriesData = [];

			for(var i=0; i<chartDataSets.length; i++)
			{
				var chartDataSet = chartDataSets[i];
				var dataSetName = chartUtil.dataSetName(chartDataSet);
				var result = chartUtil.resultIndex(results, i);

				var np = chartUtil.dataSetPropertyOfSign(chartDataSet, "name");
				var npv = chartUtil.resultColumnArrays(result, np);
				var vp = chartUtil.dataSetPropertyOfSign(chartDataSet, "value");
				var nvv = chartUtil.resultNameValueObjects(result, np, vp);
				
				legendData = legendData.concat(npv);
				seriesData = seriesData.concat(nvv);
			}
			
			var options = { legend: { data: legendData }, series: [ {data: seriesData } ] };
			chart.echarts.chart.setOption(options);
		}
	}
}