(function(plugin)
{
	return chartFactory.chartSupport.mapScatterRippleRenderer(plugin);
})
(plugin);