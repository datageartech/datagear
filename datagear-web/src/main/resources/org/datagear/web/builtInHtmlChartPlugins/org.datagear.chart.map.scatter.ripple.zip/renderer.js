(function(plugin)
{
	var r =
	{
		asyncRender: true,
		render: function(chart)
		{
			chartFactory.chartSupport.mapScatterRippleRender(chart);
		},
		asyncUpdate: true,
		update: function(chart, results)
		{
			chartFactory.chartSupport.mapScatterRippleUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.mapScatterRippleResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.mapScatterRippleDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.mapScatterRippleOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.mapScatterRippleOff(chart, eventType, handler);
		}
	};
	
	return r;
})
(plugin);