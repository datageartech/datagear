(function(plugin)
{
	var r =
	{
		render: function(chart)
		{
			var options =
			{
				dg:
				{
					horizontal: true, symbol: "star", symbolSize: "50%",
					symbolMargin: "10%", symbolRepeat: true, symbolRepeatForBg: "fixed"
				}
			};
			
			chartFactory.chartSupport.pictorialBarProgressRender(chart, options);
		},
		update: function(chart, results)
		{
			chartFactory.chartSupport.pictorialBarProgressUpdate(chart, results);
		},
		resize: function(chart)
		{
			chartFactory.chartSupport.pictorialBarProgressResize(chart);
		},
		destroy: function(chart)
		{
			chartFactory.chartSupport.pictorialBarProgressDestroy(chart);
		},
		on: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.pictorialBarProgressOn(chart, eventType, handler);
		},
		off: function(chart, eventType, handler)
		{
			chartFactory.chartSupport.pictorialBarProgressOff(chart, eventType, handler);
		}
	};
	
	return r;
})
(plugin);