(function(plugin)
{
	return chartFactory.chartSupport.mapLinesRenderer(plugin);
})
(plugin);