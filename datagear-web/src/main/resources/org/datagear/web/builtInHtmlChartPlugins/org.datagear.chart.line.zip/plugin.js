{
	id : 'org.datagear.chart.line',
	nameLabel : '折线图',
	descLabel : '折线图',
	dataSigns :
	[
		{ name : "xvalue", nameLabel : "横坐标", required: true, multiple: false },
		{ name : "yvalue", nameLabel : "纵坐标", required: true, multiple: true }
	],
	version: "0.1.0",
	order : 100,
	chartRender:
	{
	/**
	 * 依赖：
	 * chartUtil
	 * echarts
	 */
		render: function(chart)
		{
			chart.echarts = {};
			
			var options =
			{
				xAxis: {
					type: 'category',
					boundaryGap: false,
					data: []
				},
				yAxis: {
					type: 'value',
				},
				series: [{
					data: [],
					type: 'line'
				}]
			};
			
			chart.echarts.chart = chartUtil.echarts.init(chart, options);
		},
		update: function(chart, results)
		{
			var chartDataSet = chartUtil.firstChartDataSet(chart);
			var result = chartUtil.firstResult(results);
			
			var xp = chartUtil.dataSetPropertyOfSign(chartDataSet, "xvalue");
			var yp = chartUtil.dataSetPropertyOfSign(chartDataSet, "yvalue");
			
			var xdatas = chartUtil.dataPropertyValues(result, xp);
			var ydatas = chartUtil.dataPropertyValues(result, yp);
			
			var options = { xAxis : { data : xdatas }, series : [ { data : ydatas } ] };
			chart.echarts.chart.setOption(options);
		}
	}
}