{
	id: "org.datagear.chart.line",
	nameLabel: "折线图",
	descLabel: "折线图",
	dataSigns:
	[
		{ name: "xvalue", nameLabel: "横坐标", required: true, multiple: false },
		{ name: "yvalue", nameLabel: "纵坐标", required: true, multiple: true }
	],
	version: "0.1.0",
	order: 112,
	chartRender:
	{
	/**
	 * 依赖：
	 * chartUtil
	 * echarts
	 */
		render: function(chart)
		{
			var chartDataSet = chartUtil.firstChartDataSet(chart);
			var xp = chartUtil.dataSetPropertyOfSign(chartDataSet, "xvalue");
			var yp = chartUtil.dataSetPropertyOfSign(chartDataSet, "yvalue");
			
			chart.echarts = {};
			
			var options =
			{
				title: {
			        text: chartUtil.propertyValueName(chart)
			    },
				tooltip:
				{
					trigger: "item"
				},
				legend:
				{
					data: []
				},
				xAxis: {
					name: chartUtil.dataSetPropertyLabel(xp),
					nameGap: 5,
					type: "category",
					boundaryGap: false
				},
				yAxis: {
					name: chartUtil.dataSetPropertyLabel(yp),
					nameGap: 5,
					type: "value",
				},
				series: [{
					name: "",
					type: "line",
					symbol: "emptyCircle",
					symbolSize: 4,
					data: []
				}]
			};
			
			$.extend(options, chartUtil.chartElementOptions(chart));
			
			chart.echarts.chart = chartUtil.echarts.init(chart, options);
		},
		update: function(chart, results)
		{
			var chartDataSets = chartUtil.chartDataSets(chart);
			
			var legendData = [];
			var series = [];
			
			for(var i=0; i<chartDataSets.length; i++)
			{
				var chartDataSet = chartDataSets[i];
				var dataSetName = chartUtil.dataSetName(chartDataSet);
				var properties = [chartUtil.dataSetPropertyOfSign(chartDataSet, "xvalue"), chartUtil.dataSetPropertyOfSign(chartDataSet, "yvalue")];
				var result = chartUtil.resultIndex(results, i);
				var data = chartUtil.resultRowArrays(result, properties);
				
				legendData[i] = dataSetName;
				series[i] = {name: dataSetName, type: "line", symbol: "emptyCircle", symbolSize: 5, data: data};
			}
			
			var options = { legend: {data: legendData}, series: series };
			chart.echarts.chart.setOption(options);
		}
	}
}