{
	id : 'plugin04',
	nameLabel :
	{
		value : '折线图',
		localeValues :
		{
			'en' : 'line chart',
			'zh' : '折线中文'
		}
	},
	icons : { "light" : "icon-01.png", "dark" : "icons/icon-02.png" },
	order : 1,
	chartRender: {}
}