(function(chart)
{
	chart.render = function(){};
	chart.update = function(dataSets){};
})
($CHART);
