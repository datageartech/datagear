/** 独立插件渲染器文件 */
(function(localPlugin)
{
	var r =
	{
		render: function(chart){}
	};
	
	return r;
})(plugin);